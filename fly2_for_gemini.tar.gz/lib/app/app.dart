import 'package:flutter/material.dart';
import '../features/live/presentation/live_screen.dart';
import '../features/archive/presentation/archive_screen.dart';
import '../features/maps/presentation/maps_screen.dart';
import '../features/settings/presentation/settings_screen.dart';

class Fly2App extends StatelessWidget {
  const Fly2App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FLY2',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const _RootShell(),
    );
  }
}

class _RootShell extends StatefulWidget {
  const _RootShell();

  @override
  State<_RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<_RootShell> {
  int index = 0;

  final screens = const [
    LiveScreen(),
    ArchiveScreen(),
    MapsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.flight), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.archive), label: 'Archive'),
          NavigationDestination(icon: Icon(Icons.map), label: 'Maps'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
